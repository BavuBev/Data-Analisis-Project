﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace BOOKROOM
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        BindingSource binder = new BindingSource();
        private void btnList_Click(object sender, EventArgs e)
        {
            //Form3 F3 = new Form3();
            //F3.Show();
            String conString;
            
          
            conString = Properties.Settings.Default.BookroomConnectionString;
            SqlConnection con = new SqlConnection(conString);
            con.Open();

            SqlCommand cmd = new SqlCommand("Textbooks", con);
            
            

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dataGridView1.DataSource = binder;
            binder.DataSource = dataTable;

            con.Close();


        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            String BookID;
            String Title;
            String EditionNo;
            String EditionYear;
            String DisciplineAndSubDiscipline;

            DataGridViewRow selectRow = dataGridView1.Rows[e.RowIndex];
            BookID = selectRow.Cells[0].Value.ToString();
            Title = selectRow.Cells[1].Value.ToString();
            EditionNo = selectRow.Cells[2].Value.ToString();
            EditionYear = selectRow.Cells[3].Value.ToString();
            DisciplineAndSubDiscipline = selectRow.Cells[4].Value.ToString();

            txtID.Text = BookID;
            txtTitle.Text = Title;
            txtPEditionNo.Text = EditionNo;
            txtPEditionYear.Text = EditionYear;
            txtDisSub.Text = DisciplineAndSubDiscipline;

        }
    }
}
