﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace BOOKROOM
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        BindingSource binder = new BindingSource();
        private void btnSignUp_Click(object sender, EventArgs e)
        {

            Form3 f3 = new Form3();
            f3.Show();

            
            String NameIdValue = (txtName.Text);
            String SurnameIdValue = (txtSurname.Text);
            String StudentNoIdValue = (txtStudent.Text);
            String PasswordIdValue = (txtPassword.Text);

            

            MessageBox.Show("ACCOUNT ACTIVATED");


           
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
