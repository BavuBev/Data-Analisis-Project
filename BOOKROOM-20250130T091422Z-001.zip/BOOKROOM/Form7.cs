﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace BOOKROOM
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
        BindingSource binder = new BindingSource();
        private void btnSearch_Click(object sender, EventArgs e)
        {
            String conString;
            int DisciplineIdValue = int.Parse(txtDiscipline.Text);
            
            conString = Properties.Settings.Default.BookroomConnectionString;
            SqlConnection con = new SqlConnection(conString);
            con.Open();

            SqlCommand cmd = new SqlCommand("GetlinkDisSubById", con);
            
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@GetLinkId", DisciplineIdValue));
            
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);
            dataGridView1.DataSource = binder;
            binder.DataSource = dataTable;

            con.Close();

        }
    }
}
