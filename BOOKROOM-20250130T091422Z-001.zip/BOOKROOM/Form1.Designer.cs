﻿namespace BOOKROOM
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sTUDENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREATEANACCOUNTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dOWNLOADATEXTBOOKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lECTURERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cREATEANACCOUNTToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGINToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.uPLOADATEXTBOOKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sTUDENTSToolStripMenuItem,
            this.lECTURERToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sTUDENTSToolStripMenuItem
            // 
            this.sTUDENTSToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cREATEANACCOUNTToolStripMenuItem,
            this.lOGINToolStripMenuItem,
            this.dOWNLOADATEXTBOOKToolStripMenuItem});
            this.sTUDENTSToolStripMenuItem.Name = "sTUDENTSToolStripMenuItem";
            this.sTUDENTSToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.sTUDENTSToolStripMenuItem.Text = "STUDENT";
            // 
            // cREATEANACCOUNTToolStripMenuItem
            // 
            this.cREATEANACCOUNTToolStripMenuItem.Name = "cREATEANACCOUNTToolStripMenuItem";
            this.cREATEANACCOUNTToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.cREATEANACCOUNTToolStripMenuItem.Text = "CREATE AN ACCOUNT";
            this.cREATEANACCOUNTToolStripMenuItem.Click += new System.EventHandler(this.cREATEANACCOUNTToolStripMenuItem_Click);
            // 
            // lOGINToolStripMenuItem
            // 
            this.lOGINToolStripMenuItem.Name = "lOGINToolStripMenuItem";
            this.lOGINToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.lOGINToolStripMenuItem.Text = "LOGIN";
            this.lOGINToolStripMenuItem.Click += new System.EventHandler(this.lOGINToolStripMenuItem_Click);
            // 
            // dOWNLOADATEXTBOOKToolStripMenuItem
            // 
            this.dOWNLOADATEXTBOOKToolStripMenuItem.Name = "dOWNLOADATEXTBOOKToolStripMenuItem";
            this.dOWNLOADATEXTBOOKToolStripMenuItem.Size = new System.Drawing.Size(213, 22);
            this.dOWNLOADATEXTBOOKToolStripMenuItem.Text = "DOWNLOAD A TEXTBOOK";
            this.dOWNLOADATEXTBOOKToolStripMenuItem.Click += new System.EventHandler(this.dOWNLOADATEXTBOOKToolStripMenuItem_Click);
            // 
            // lECTURERToolStripMenuItem
            // 
            this.lECTURERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cREATEANACCOUNTToolStripMenuItem1,
            this.lOGINToolStripMenuItem1,
            this.uPLOADATEXTBOOKToolStripMenuItem});
            this.lECTURERToolStripMenuItem.Name = "lECTURERToolStripMenuItem";
            this.lECTURERToolStripMenuItem.Size = new System.Drawing.Size(73, 20);
            this.lECTURERToolStripMenuItem.Text = "LECTURER";
            // 
            // cREATEANACCOUNTToolStripMenuItem1
            // 
            this.cREATEANACCOUNTToolStripMenuItem1.Name = "cREATEANACCOUNTToolStripMenuItem1";
            this.cREATEANACCOUNTToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.cREATEANACCOUNTToolStripMenuItem1.Text = "CREATE AN ACCOUNT";
            this.cREATEANACCOUNTToolStripMenuItem1.Click += new System.EventHandler(this.cREATEANACCOUNTToolStripMenuItem1_Click);
            // 
            // lOGINToolStripMenuItem1
            // 
            this.lOGINToolStripMenuItem1.Name = "lOGINToolStripMenuItem1";
            this.lOGINToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.lOGINToolStripMenuItem1.Text = "LOGIN";
            this.lOGINToolStripMenuItem1.Click += new System.EventHandler(this.lOGINToolStripMenuItem1_Click);
            // 
            // uPLOADATEXTBOOKToolStripMenuItem
            // 
            this.uPLOADATEXTBOOKToolStripMenuItem.Name = "uPLOADATEXTBOOKToolStripMenuItem";
            this.uPLOADATEXTBOOKToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.uPLOADATEXTBOOKToolStripMenuItem.Text = "UPLOAD A TEXTBOOK";
            this.uPLOADATEXTBOOKToolStripMenuItem.Click += new System.EventHandler(this.uPLOADATEXTBOOKToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.BackgroundImage = global::BOOKROOM.Properties.Resources.Screenshot_20220303_135952_Google_Play_Store;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "BOOKROOM";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREATEANACCOUNTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dOWNLOADATEXTBOOKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lECTURERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cREATEANACCOUNTToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem lOGINToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem uPLOADATEXTBOOKToolStripMenuItem;
    }
}

